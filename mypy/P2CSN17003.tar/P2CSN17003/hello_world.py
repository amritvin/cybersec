print"Hello, world!"
